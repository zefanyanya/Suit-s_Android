package umn.ac.id.uas_suits;

public class ReadWriteUserDetails {
    public String doB, gender, phone;

    public ReadWriteUserDetails(){};

    public ReadWriteUserDetails(String textDoB, String textGender, String textPhone){
        this.doB = textDoB;
        this.gender = textGender;
        this.phone = textPhone;
    }
}
